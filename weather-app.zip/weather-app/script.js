const apiKey = "bc00aee8b69fc31f7d9520d5a5623eb4";

const weatherDataEle = document.querySelector(".weather-data");
const cityNameEle = document.querySelector("#city-name");
const cityDisplay = document.querySelector(".city-name h2"); // City Name Display
const formEle = document.querySelector("form");
const imgIcon = document.querySelector(".icon");
const unitToggle = document.querySelector("#unit-toggle");
const currentCityBtn = document.querySelector("#current-city-btn"); // Current City Button

let currentUnit = 'metric'; // Default unit: Celsius

function getWeatherData(city, unit = 'metric') {
    const apiURL = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=${unit}`;
    return axios.get(apiURL).then(response => response.data);
}

function getWeatherByLocation(lat, lon, unit = 'metric') {
    const apiURL = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=${unit}`;
    return axios.get(apiURL).then(response => response.data);
}

function getLocationWeather() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition((position) => {
            const { latitude, longitude } = position.coords;
            getWeatherByLocation(latitude, longitude, currentUnit)
                .then((data) => {
                    updateWeatherUI(data);
                })
                .catch((error) => {
                    console.error(error);
                    weatherDataEle.querySelector(".desc").textContent = "Error fetching weather!";
                    imgIcon.innerHTML = "";
                    weatherDataEle.querySelector(".details").innerHTML = `<div>Could not fetch data.</div>`;
                });
        }, () => {
            alert("Geolocation permission denied. Please enter a city.");
        });
    } else {
        alert("Geolocation is not supported by your browser.");
    }
}

function getWeatherBackground(weatherCondition) {
    switch (weatherCondition.toLowerCase()) {
        case 'clear':
            return 'url("img/clear.gif")';  // Local Clear sky gif
        case 'clouds':
            return 'url("img/clouds.gif")';  // Local Clouds gif
        case 'rain':
            return 'url("img/rain.gif")';  // Local Rain gif
        case 'snow':
            return 'url("img/snow.gif")';  // Local Snow gif
        case 'thunderstorm':
            return 'url("img/thunderstorm.gif")';  // Local Thunderstorm gif
        case 'drizzle':
            return 'url("img/drizzle.gif")';  // Local Drizzle gif
        case 'mist':
            return 'url("img/mist.gif")';  // Local Mist gif
        case 'haze':
            return 'url("img/haze.gif")';  // Local Haze gif
        default:
            return 'url("img/default.gif")';  // Local Default gif
    }
}

function updateWeatherUI(data) {
    const temperature = currentUnit === 'metric' ? Math.floor(data.main.temp) : Math.floor(data.main.temp * 9/5 + 32);
    const description = data.weather[0].description;
    const icon = data.weather[0].icon;
    const condition = data.weather[0].main;

    cityDisplay.textContent = data.name; // Update City Name

    const details = [
        `Temperature: ${temperature}°${currentUnit === 'metric' ? 'C' : 'F'}`,
        `Humidity: ${data.main.humidity}%`,
        `Weather Condition: ${condition}`
    ];

    weatherDataEle.querySelector(".desc").textContent = description;
    imgIcon.innerHTML = `<img src="https://openweathermap.org/img/wn/${icon}.png" alt="Weather Icon">`;

    weatherDataEle.querySelector(".details").innerHTML = details
        .map(detail => `<div>${detail}</div>`)
        .join("");

    //Update background based on the weather (full-screen background)
    document.body.style.backgroundImage = `${getWeatherBackground(condition)}`;
    document.body.style.backgroundSize = "cover";  // Ensures the background covers the entire screen
    document.body.style.backgroundPosition = "center";  // Centers the background
    document.body.style.backgroundAttachment = "fixed";  // Keeps the background fixed while scrolling
}

formEle.addEventListener("submit", (e) => {
    e.preventDefault();
    const cityValue = cityNameEle.value.trim();

    if (!cityValue) {
        alert("Please enter a city name.");
        return;
    }

    getWeatherData(cityValue, currentUnit)
        .then((data) => {
            updateWeatherUI(data);
        })
        .catch((error) => {
            console.error(error);
            weatherDataEle.querySelector(".desc").textContent = "City not found!";
            imgIcon.innerHTML = "";
            weatherDataEle.querySelector(".details").innerHTML = `<div>${error.response ? error.response.data.message : "Try again."}</div>`;
        });
});

//Handle unit toggle (Celsius <-> Fahrenheit)
unitToggle.addEventListener("change", () => {
    currentUnit = currentUnit === 'metric' ? 'imperial' : 'metric';
    getLocationWeather(); 
    const cityValue = cityNameEle.value.trim();
    if (cityValue) {
        getWeatherData(cityValue, currentUnit)
            .then((data) => updateWeatherUI(data))
            .catch(console.error);
    }
});

// Handle Current City Button
currentCityBtn.addEventListener("click", () => {
    getLocationWeather();
});

//Fetch location weather on load
getLocationWeather();
